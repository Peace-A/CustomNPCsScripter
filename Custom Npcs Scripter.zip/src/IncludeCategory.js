
module.exports.includesCategory = function (target$, relatedTarget$) {
  
  let contextMenuData = getGlobalContextmenudata( target$ )
  let category        = relatedTarget$.attr("element-category")
  let relatedCode     = relatedTarget$.attr("output-code")
  
  console.log("relatedCodeMENUDATA", contextMenuData)
  if ( !contextMenuData.includes(category) ) return false
    
  let listComponent = require(`./contextmenulist/${category}`)
  if (!Array.isArray(listComponent)) 
    for (let i in listComponent) 
      listComponent = listComponent[i].children
    
  console.log("code",relatedCode)
  return (function findElement(component) {
    for (let e of component) {
      console.log("comp", e)
      if (e.element && e.element.code === relatedCode)
        return true
      else if ( e.children )
        return findElement(e.children)
    }
    return false
  })(listComponent)
} 

function getGlobalContextmenudata( target$ ) {
  let result = []
  if (target$.attr === undefined) return result
  if (target$.attr("context-menu-data")) {
    result = target$.attr("context-menu-data").split(' ').concat(result)
    result = getGlobalContextmenudata(target$.parent().parent()).concat(result)
  }
  return result
}

const { assertChildrens } = require("../AssertContextMenuList") 

let result = {
    title: "объект",
    children: []
}

assertChildrens(result, require("./entity"), "event.entity.")

module.exports = result 
 
 

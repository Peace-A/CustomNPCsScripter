const { ElementType, ReturnsType } = require("../ContextMenuConstants")

module.exports = {
  event: {
    title: "События",
    children: [
      {
        title: "В начале",
        element: {
          type: ElementType.UL,
          cannot_be_inherits: true,
          header: "В начале",
          code: "function init() {[npc api operators]}"
        }
      },
      {
        title: "Ежесекундно",
        element: {
          type: ElementType.UL,
          cannot_be_inherits: true,
          header: "Ежесекундно",
          code: "function tick() {[npc api operators]}"
        }
      },
      {
        title: "Когда взаимодействует игрок",
        element: {
          type: ElementType.UL,
          cannot_be_inherits: true,
          header: "Когда взаимодействует игрок",
          code: "function interact() {[npc api player operators]}"
        }
      },
      {
        title: "Когда получает урон",
        element: {
          type: ElementType.UL,
          cannot_be_inherits: true,
          header: "Когда получает урон",
          code: "function damaged() {[npc api source-entity operators]}"
        }
      },
      {
        title: "Когда умер",
        element: {
          type: ElementType.UL,
          cannot_be_inherits: true,
          header: "Когда умер",
          code: "function died() {[npc api source-entity operators]}"
        }
      },
      {
        title: "Когда нанёс урон",
        element: {
          type: ElementType.UL,
          cannot_be_inherits: true,
          header: "Когда нанёс урон",
          code: "function meleeAttack() {[npc api target-entitylivingbase operators]}"
        }
      },
      {
        title: "Когда выстрелел",
        element: {
          type: ElementType.UL,
          cannot_be_inherits: true,
          header: "Когда выстрелел",
          code: "function rangedLaunched() {[npc api target-entitylivingbase operators]}"
        }
      },
      {
        title: "Когда увидил врага",
        element: {
          type: ElementType.UL,
          cannot_be_inherits: true,
          header: "Когда увидил врага",
          code: "function target() {[npc api entity-entitylivingbase operators]}"
        }
      },
      {
        title: "Когда потерял из виду врага",
        element: {
          type: ElementType.UL,
          cannot_be_inherits: true,
          header: "Когда потерял из виду врага",
          code: "function targetLost() {[npc api target-entitylivingbase operators]}"
        }
      },
      {
        title: "Когда убил кого-то",
        element: {
          type: ElementType.UL,
          cannot_be_inherits: true,
          header: "Когда убил кого-то",
          code: "function kill() {[npc api entity-entitylivingbase operators]}"
        }
      },
      {
        title: "При прикосновении",
        element: {
          type: ElementType.UL,
          cannot_be_inherits: true,
          header: "При прикосновении",
          code: "function collide() {[npc api entity-entity operators]}"
        }
      }
    ]
  }
}

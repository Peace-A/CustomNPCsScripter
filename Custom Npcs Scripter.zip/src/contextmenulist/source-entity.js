const { assertChildrens } = require("../AssertContextMenuList") 

let result = {
    title: "объект",
    children: []
}

assertChildrens(result, require("./entitylivingbase"), "event.source.")

module.exports = result 
 

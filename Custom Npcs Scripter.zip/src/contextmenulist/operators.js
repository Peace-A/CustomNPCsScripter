const { ElementType, ReturnsType } = require("../ContextMenuConstants") 

module.exports = {
    operators: {
        title: "Операторы",
        children: [
            {
                title: "Если",
                element: {
                    type: ElementType.SIMPLE,
                    header: "Если {bool}",
                    code: "if ({}) {[]}"
                }
            },
            {
                title: "x=y",
                element: {
                    type: ElementType.SIMPLE,
                    returns: ReturnsType.BOOL,
                    header: "{number string}={number string}",
                    code: "{}=={}"
                }   
            },
            {
                title: "x>y",
                element: {
                    type: ElementType.SIMPLE,
                    returns: ReturnsType.BOOL,
                    header: "{number}>{number}",
                    code: "{}>{}"
                }   
            },
            {
                title: "x>=y",
                element: {
                    type: ElementType.SIMPLE,
                    returns: ReturnsType.BOOL,
                    header: "{number}>={number}",
                    code: "{}>={}"
                }   
            },
            {
                title: "x<y",
                element: {
                    type: ElementType.SIMPLE,
                    returns: ReturnsType.BOOL,
                    header: "{number}<{number}",
                    code: "{}<{}"
                }   
            },
            {
                title: "x<=y",
                element: {
                    type: ElementType.SIMPLE,
                    returns: ReturnsType.BOOL,
                    header: "{number}<={number}",
                    code: "{}<={}"
                }   
            }
        ]
    }
}
 

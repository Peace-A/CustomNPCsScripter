const $ = require("jquery")

module.exports = () => {

  $(".main-row").append( MainScreen() )

}

function MainScreen() {
  return $(`<main class="main-screen"></main>`)
      .append($(`<h1>Создайте новый скрипт для...</h1>`))
      .append( createBtnRowLoader("НПС", ["npc-events"]) )
      .append( createBtnRowLoader("Игрока", ["operators"]) )
}

function createBtnRowLoader(name, tagList) {
  return $(`<input type="button" class="btn btn-lg btn-primary" value="${name}" >`)
    .click( ( { target } ) => {

      // set propertyes for main row
      $(target).parent().parent().attr("context-menu-data", tagList.join(' '))

      // remove main screen
      $(target).parent().remove()

    })
}

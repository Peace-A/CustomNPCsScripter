 
module.exports.assertChildrens = (obj1, array, preText="") => {
    for (let element of array) {
        element.code = preText + element.code
        obj1.children.push(element)
    }
}

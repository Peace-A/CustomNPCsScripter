


module.exports.createContextMenuByIdList = function createContextMenuByIdList(idList, {target$}) {

  const DO_ELEMENT_TYPE_SIMPLE_HEADER = 0
  const DO_ELEMENT_TYPE_SIMPLE_UL     = 1

  var ContextMenu = new Proxy(initFunc, {
      construct(target, args) {
          return new target(...args)
      }
  }) 

  var result = new ContextMenu()
  
  idList = idList.filter(e=>e!=="")
  for ( let id of idList )
      result.assign(  getTemplateById(id, {type:null && getTypeFromContextData(target$.attr("context-menu-data").split(' '))}) )
      
  return result
    
  function getTemplateById(ID, filterList={}) {
    console.log(`ID: ${ID}, filterList: ${JSON.stringify(filterList)}`)
    let result = require(`./contextmenulist/${ID}`)
        
    if (filterList.onlyInherits === true) 
        result = filter( result, t=>t.element.cannot_be_inherits !== true )
        
    if (filterList.type !== undefined)
        result = filter( result, t=>console.log(filterList.type, t) || console.log(t.element.returns == filterList.type) || t.element.returns == filterList.type )
        
        
    void function setCategory(elements) {
      for (let i in elements) {
        let elem = elements[i]
        if ( elem.hasOwnProperty("children") )
          setCategory(elem.children)
        else
          elem.category = ID
      } 
    }( result )
    return result
    
    function filter( templates, filterFunc ) {
        let result = JSON.parse(JSON.stringify(templates))

        for (let i in templates)
            void function removeFilterElements(r) {
                let children = r.children
                for ( let i in children ) {
                    if ( filterFunc(children[i]) === false)
                        delete children[i]
                    else if (children[i].children !== undefined)
                        removeFilterElements(children[i].children)
                }

                if (isEmptyObject(children))
                    delete r.children

                //children.flat()
            }(result[i])

        return result

    }
    
  }

  function initFunc() {
      
      this.elementTemplateList = {}
      
      this.assign = function (assignObject) {
          assign(this.elementTemplateList, assignObject)
      }
   
      this.getHTML = function () {
           
        const This = this

          void function appendTemplateByParent(parent$) {
            if (parent$.attr === undefined) return
            if (parent$.attr("context-menu-data")) {
              let dataList = parent$.attr("context-menu-data").split(' ')
              for (let template of dataList )
                This.assign( getTemplateById(template, { onlyInherits: true, type: getTypeFromContextData( This.target$.attr("context-menu-data").split(' ') ) } ) )
              appendTemplateByParent(parent$.parent().parent())
            }
          }(This.target$.is("ul") ? This.target$.parent().parent() : This.target$.parent().parent().parent())
          

          console.log(this.elementTemplateList)
          // Add elements from list
          let result$ = $("<ul></ul>")
        for (let i in this.elementTemplateList)
          if (this.elementTemplateList[i].element !== undefined || this.elementTemplateList[i].children !== undefined)
            result$.append( createElement(this.elementTemplateList[i]) )


          return result$.children()
              
          
          
        function createElement(template) {

                      
              
              let element$ = $(`<li class="ui-menu-item"><div class="ui-menu-item-wrapper" aria-haspopup="${!!template.children}" role="menuitem">${template.title}</div></li>`)
              
              if (template.children) {
                  
                  let list$ = $(`<ul style="display: none" role="menu" aria-hidden="true" aria-expanded="false" class="ui-menu ui-widget ui-widget-content ui-front"></ul>`)
                  element$.children().eq(0).append(`<span class="ui-menu-icon ui-icon ui-icon-caret-1-e"></span>`)
                  
                  for (let childElementTemplateIndex in template.children)
                      list$.append( createElement(template.children[childElementTemplateIndex]) )
                      
                  element$.append(list$)
                      
              }
              
              if (template.element) {
                element$.click(function () {
                  let headerOutElementList = [], headerInText = template.element.header

                  headerOutElementList = getHeaderInfoFrom(headerInText, '{', '}', template.category)
                  
                  let result$ = $(`<li class="doElement" element-category="${template.category}" ><header></header></li>`)
                  if (headerOutElementList.length !== 0)
                      result$.children().append(...headerOutElementList)
                  else
                      result$.children().html(headerInText)
                  if (template.element.type === DO_ELEMENT_TYPE_SIMPLE_UL) result$.append($(`<ul class="context-menu-caller" context-menu-data="${getCodeChildrenInfo(template.element.code, '[', ']').join(' ')}"></ul>`))
                  result$.attr("output-code", template.element.code)
                  result$.attr("returns-type", template.element.returns)
                  result$.attr("cannot-inherits-bool", template.element.cannot_be_inherits)
                  This.target$.append(result$)
                  $("#context-menu").hide()
                }) 
              }
              
              return element$
                      
              
          }
          
      }

  }

}


function assign(obj1, obj2) {
    for (let elementIndex in obj2)
        if (!obj1.hasOwnProperty(elementIndex)) 
            obj1[elementIndex] = obj2[elementIndex]
        else if (typeof obj1[elementIndex] === "object" && typeof obj2[elementIndex] === "object")
            assign(obj1[elementIndex], obj2[elementIndex])
}

function getHeaderInfoFrom(text, startSymbol, endSymbol, category) {
  let result = []
  for (
    let callStartPos = text.indexOf(startSymbol),
    callEndPos = text.indexOf(endSymbol),
    len = text.length;

    callStartPos !== -1;

    text = text.slice(callEndPos+1, len),
    callStartPos = text.indexOf(startSymbol),
    callEndPos = text.indexOf(endSymbol),
    len = text.length
  ) {
    result.push( text.slice(0, callStartPos) )
    let argumentsArray = text.slice(callStartPos+1, callEndPos).split(' ')
    result.push( $(`<div class="context-menu-caller context-menu-caller-small" element-category="${category}"  context-menu-data="${argumentsArray.join(' ')}" ></div>`) )
  }
  return result
} 

function getCodeChildrenInfo(code, startSymbol, endSymbol) {
  let callStartPos = code.indexOf(startSymbol)
  let callEndPos = code.indexOf(endSymbol)
  let result = code.slice(callStartPos+1, callEndPos).split(' ')
  return result
}

function getTypeFromContextData( dataArray ) {
    let typeList = ["number", "string"]
    
    for (let type of typeList)
        if (dataArray.includes(type))
            return type
    
    return null
}

function isEmptyObject( obj ) {
  for (let i in obj)
    if (obj.hasOwnProperty(i))
      return false
  return true
}
